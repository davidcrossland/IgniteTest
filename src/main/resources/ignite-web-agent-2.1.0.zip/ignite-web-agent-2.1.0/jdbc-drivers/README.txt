Ignite Web Agent
======================================

If you are are planning to load cache type metadata from your existing databases
you need to copy JDBC drivers in this folder.

This is default folder for JDBC drivers.

Also, you could specify custom folder using option: "-d CUSTOM_PATH_TO_FOLDER_WITH_JDBC_DRIVERS".

