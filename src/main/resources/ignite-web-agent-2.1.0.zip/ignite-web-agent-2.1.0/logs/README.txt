Ignite Web Agent
======================================

This is folder for agent logs.

